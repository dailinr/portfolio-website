export const PORTFOLIO_GUTTER =
  "px-8 md:px-24" as const;

export const SECTION_LABEL =
  "text-tertiary uppercase tracking-[0.25em] text-xs font-bold mb-4" as const;

export const SECTION_HEADLINE =
  "text-3xl md:text-5xl font-medium tracking-tight text-foreground" as const;

export const TIMELINE_LINE =
  "relative border-l border-white/10 ml-3 md:ml-4" as const;

export const TIMELINE_DOT =
  "absolute -left-[7px] top-2 w-3.5 h-3.5 bg-primary rounded-full shadow-[0_0_15px_3px_rgba(248,205,104,0.4)]" as const;

export const EXPERIENCE_ROLE_HEADLINE =
  "text-2xl font-bold text-primary" as const;

export const EXPERIENCE_COMPANY_HEADLINE =
  "text-lg text-foreground mt-1 font-medium" as const;

export const EXPERIENCE_BODY =
  "mt-5 text-tertiary leading-relaxed text-[16px] max-w-2xl" as const;

export const EXPERIENCE_BADGE =
  "px-3.5 py-1.5 text-xs font-medium border border-white/10 rounded-md text-foreground bg-white/5" as const;
