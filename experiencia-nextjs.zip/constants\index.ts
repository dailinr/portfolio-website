export const EXPERIENCE_SECTION_CONTENT = {
  label: "Experiencia",
  headline: {
    main: "Hitos profesionales ",
    highlight: "& impacto",
  },
  experiences: [
    {
      id: "czlabs",
      role: "Frontend Developer",
      company: "CZLabs",
      period: "Nov 2025 — Jul 2026",
      description:
        "Desarrollo de interfaces de usuario modernas y escalables. Implementación de arquitecturas frontend fluidas enfocadas en la optimización del rendimiento y la experiencia del usuario, integrando lógicas de estado global complejas y consumos de APIs eficientes.",
      technologies: [
        "Next.js",
        "React Native",
        "TypeScript",
        "Zustand",
        "Tailwind CSS",
      ],
    },
  ],
};
