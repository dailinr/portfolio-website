import { EXPERIENCE_SECTION_CONTENT } from "../../constants";
import {
  EXPERIENCE_BADGE,
  EXPERIENCE_BODY,
  EXPERIENCE_COMPANY_HEADLINE,
  EXPERIENCE_ROLE_HEADLINE,
  PORTFOLIO_GUTTER,
  SECTION_HEADLINE,
  SECTION_LABEL,
  TIMELINE_DOT,
  TIMELINE_LINE,
} from "../../constants/layout";

export default function ExperienceSection() {
  const { label, headline, experiences } = EXPERIENCE_SECTION_CONTENT;

  return (
    <section 
      id="experiencia" 
      className={`w-full bg-background selection:bg-primary selection:text-background min-h-screen py-8 md:py-24 ${PORTFOLIO_GUTTER}`}
    >
      <div className="max-w-5xl mx-auto">
        {/* Encabezado */}
        <div className="mb-16 md:mb-24 flex flex-col md:items-start items-center text-center md:text-left">
          <span className={SECTION_LABEL}>
            {label}
          </span>
          <h2 className={SECTION_HEADLINE}>
            {headline.main} <span className="text-secondary">{headline.highlight}</span>
          </h2>
        </div>

        {/* Estructura del Timeline */}
        <div className={TIMELINE_LINE}>
          {experiences.map((exp) => (
            <div key={exp.id} className="relative pl-8 md:pl-12 pb-16">
              
              {/* Punto del Timeline con Resplandor */}
              <div className={TIMELINE_DOT} aria-hidden="true" />

              {/* Contenedor Flex para separar Textos (Izquierda) y Logo/Fecha (Derecha) */}
              <div className="flex flex-col-reverse md:flex-row gap-8 md:gap-12 justify-between items-start">

                {/* Columna Izquierda: Información del Rol */}
                <div className="flex-1">
                  <h3 className={EXPERIENCE_ROLE_HEADLINE}>{exp.role}</h3>
                  <h4 className={EXPERIENCE_COMPANY_HEADLINE}>{exp.company}</h4>

                  <p className={EXPERIENCE_BODY}>
                    {exp.description}
                  </p>

                  {/* Badges de Tecnologías */}
                  <div className="flex flex-wrap gap-2.5 mt-6">
                    {exp.technologies.map((tech) => (
                      <span key={tech} className={EXPERIENCE_BADGE}>
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Columna Derecha: Fecha y Logo de la Empresa */}
                <div className="flex flex-col md:items-end gap-3 shrink-0 mt-1 md:mt-0">
                  <span className="text-tertiary text-sm font-medium tracking-wide">
                    {exp.period}
                  </span>
                  
                  {/* Contenedor del Logo */}
                  <div className="w-36 h-20 bg-white rounded-xl flex items-center justify-center p-4 shadow-lg transition-transform hover:scale-105 duration-300">
                    <svg className="w-full h-full text-slate-900" viewBox="0 0 120 40" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                      <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" fontFamily="Arial" fontWeight="900" fontSize="22" letterSpacing="-1">{exp.company}</text>
                    </svg>
                  </div>
                </div>

              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
