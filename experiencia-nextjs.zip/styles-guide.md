# Guía de Implementación

## 1. Copiar los archivos
Copia las carpetas `constants` y `components` en tu proyecto de Next.js (generalmente dentro de `src/`).

## 2. Actualizar configuración de Tailwind / CSS Global

Si estás usando **Tailwind CSS v4** (como indica tu snippet `@theme inline`), añade esto a tu archivo `app/globals.css`:

```css
@import "tailwindcss";

@theme inline {
  --font-sans: 'Plus Jakarta Sans', sans-serif;
  --color-primary: #F8CD68; /* amarillo */
  --color-primary-dark: #E0B850;
  --color-background: #191C22; 
  --color-foreground: #FFFFFD; /* blanco */
  --color-secondary: #6D7076; /* alexander */
  --color-tertiary: #898C92; /* body text gray */
}

body {
  background-color: var(--color-background);
  color: var(--color-foreground);
  font-family: var(--font-sans);
}
```

Si estás usando **Tailwind CSS v3** con `tailwind.config.ts`, actualiza tu configuración:

```typescript
import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/constants/**/*.{js,ts,jsx,tsx,mdx}", // No olvides agregar constants si tienes estilos ahí
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
      },
      colors: {
        background: "#191C22",
        foreground: "#FFFFFD",
        primary: {
          DEFAULT: "#F8CD68",
          dark: "#E0B850",
        },
        secondary: "#6D7076",
        tertiary: "#898C92",
      },
    },
  },
  plugins: [],
};
export default config;
```

## Importar el componente

Luego puedes importar tu componente en tu página principal (`page.tsx`):

```tsx
import ExperienceSection from "@/components/sections/ExperienceSection";

export default function Home() {
  return (
    <main>
      {/* Otras secciones... */}
      <ExperienceSection />
    </main>
  );
}
```
